package com.example.riddhi.project_final_lambton;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class search_agent extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_agent);
    }
}
